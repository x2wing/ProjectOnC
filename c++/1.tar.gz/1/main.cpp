#include <iostream>

using namespace std;

struct ELEM {
	int value;
	ELEM *pNext;
}*head; //ELEM *head;

void AddItem(int m_val)
{
	ELEM *pElem = new ELEM;
	pElem->value = m_val;
	pElem->pNext = head;
	head = pElem;
}


void PrintList()
{
	ELEM *elem = head;
	while (elem)
	{
		cout<<elem->value<<endl;
		elem = elem->pNext;
	}
}


void DeleteItems(int DataItem)
{
	ELEM *elem = head; //текущий
	ELEM *prev = NULL; //предыдущий

 while (elem)
 {//пока не конец списка
    if (DataItem == elem->value)
    {
        if (elem==head)
            head=elem->pNext;
        else
        prev->pNext = elem->pNext;

        return;
    }

    prev = elem; //предыдущий стал 5-ый
    elem = elem->pNext; //текущий стал 4-ый
  }

}




int main()
{
int i;




		AddItem(1);
        AddItem(2);
        AddItem(3);
        AddItem(4);
        AddItem(5);
	//DeleteItems();


    cout<<"dub vvedi che nibud:";
    //	cin>>i;
    i=3;
    DeleteItems(i);


	PrintList();
	cout<<endl<<i<<endl;
cout<<endl<<head<<endl;

	return 0;
}
